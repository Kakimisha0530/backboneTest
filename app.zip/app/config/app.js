var Logs = {lastId:0};
Logs.Item = Backbone.Model.extend({
	defaults : {
		date : new Date().getTime()
	}
});
Logs.List = Backbone.Collection.extend({
	model : Logs.Item,
	url : "../donnees/logs.json",
	parse:function(data){
		Logs.lastId = data.lastId;
		return data.datas;
	},
	save:function(){
		var path = this.url.split("/");
		/*console.log(path);*/
		alert(path[path.length-1] + " : " + JSON.stringify(this.toJSON()));	
		writeJSON(path[path.length-1] , JSON.stringify(this.toJSON()));
	}
});

( function($) {
		Logs.ListView = Backbone.View.extend({
			tagName : 'ul',
			id : 'cates-list',
			attributes : {
				"data-role" : 'listview'
			},
			initialize : function() {
				this.collection.bind('add', this.add, this);
				this.template = _.template($('#cates-list-item-template').html());
			},
			render : function() {
				var container = this.options.viewContainer,
				    cates = this.collection,
				    template = this.template,
				    listView = $(this.el);
				$(this.el).empty();
				cates.each(function(cate) {
					listView.append(template(cate.toJSON()));
				});
				container.html($(this.el));
				container.trigger('create');
				return this;
			},
			add : function(item) {
				Logs.lastId++;
				var activitiesList = $('#cates-list'),
				    template = this.template;
				activitiesList.append(template(item.toJSON()));
				activitiesList.listview('refresh');
			}
		});

		Logs.initData = function() {
			Logs.liste = new Logs.List();
			Logs.liste.fetch({
				async : false
			});
		};
}(jQuery));

$(document).ready(function(){
	$('#add-button').on('tap', function() {
		alert("add button taped");
		Logs.liste.add({
			id : Logs.lastId + 1,
			date : new Date().getTime()
		});
		console.log(Logs.liste.models);
		Logs.liste.save();
	}); 
});

$(document).on("pagecreate", "#cates", function() {

	var containerC = $('#cates').find(":jqmData(role='content')"),
	    listView;
	Logs.initData();

	listView = new Logs.ListView({
		collection : Logs.liste,
		viewContainer : containerC
	});
	listView.render();
});

