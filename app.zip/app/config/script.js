function errorHandler(e) {
	alert(JSON.stringify(e));
	switch (e.code) {
	case FileError.QUOTA_EXCEEDED_ERR:
		msg += 'QUOTA_EXCEEDED_ERR';
		break;
	case FileError.NOT_FOUND_ERR:
		msg += 'NOT_FOUND_ERR';
		break;
	case FileError.SECURITY_ERR:
		msg += 'SECURITY_ERR';
		break;
	case FileError.INVALID_MODIFICATION_ERR:
		msg += 'INVALID_MODIFICATION_ERR';
		break;
	case FileError.INVALID_STATE_ERR:
		msg += 'INVALID_STATE_ERR';
		break;
	default:
		msg += 'Unknown Error';
		break;
	};

	alert('Error: ' + msg);
}

var appURL = "";
var appBackbone = {
	initialize : function() {
		this.bindEvents();
	},

	bindEvents : function() {
		document.addEventListener('deviceready', this.onDeviceReady, false);
	},

	onDeviceReady : function() {
		app.receivedEvent('deviceready');
		platform = window.device.platform.toLowerCase();

		if (platform.toLowerCase() == "android") {
			appURL = cordova.file.applicationStorageDirectory + "Documents/";
		} else if (platform.toLowerCase() == "ios") {
			appURL = cordova.file.documentsDirectory;
		} 
	},

	receivedEvent : function(id) {
	}
};

/*Backbone.sync = function(coll){
	console.log(coll.models);
	//writeJSON(coll.url,coll.models);
};*/

function writeJSON(filename,data) {
	window.resolveLocalFileSystemURL(appURL + "app/donnees/", function(dir) {
		alert("got main dir",dir);
		dir.getFile(filename, {create:true}, function(file) {
			alert("got the file " + file);
			alert("going to log " + data);
			file.createWriter(function(fileWriter) {				
				fileWriter.seek(fileWriter.length);				
				var blob = new Blob([data], {type:'text/json'});
				fileWriter.write(blob);
				alert("ok, in theory i worked");
			}, errorHandler);			
		});
	});
}